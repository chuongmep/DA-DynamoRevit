Source: http://code.google.com/p/simplexnoise/
This might seem it's not used, but some migration tests actually need this.
